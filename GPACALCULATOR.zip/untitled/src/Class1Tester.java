import java.util.Scanner;
public class Class1Tester {
    public static void main(String[] args) {
        //open issue #1: if they mess up, how to restart the thing

        Scanner input = new Scanner(System.in);
        //intro. giving user "disclaimer"
        System.out.println("Hello. Welcome to the GPA Calculator");
        System.out.println("Note that this code only gives a ROUGH average of your GPA and is not entirely correct.");
        System.out.println("All schools are not on the same system");

        //taking the User's general school info
        System.out.println("Enter your name: ");  //user enters name
        String userName = input.nextLine();
        System.out.println("Enter your age: ");  //user enters age
        int userAge = input.nextInt();
        System.out.println("What grade are you in?");  //user enters grade
        int userGrade = input.nextInt();


        System.out.println("How many classes are you taking?");
        int numOfClasses = input.nextInt();
        double sumOfUserCredits = 0;
        double sumOfUserGrades = 0;
        int classCounter = 0;
        for (int x = 1; x <= numOfClasses; x++) {
            classCounter++;
            System.out.println("Number of credits you get for class " + classCounter + "?");
            double numOfCredits = input.nextDouble();
            System.out.println("Is it honors or AP? 1 = Yes, 2 = No");
            int userAnswer = input.nextInt();
            System.out.println("Your grade?");
            double classGrade = input.nextDouble();
            if (userAnswer == 1) {
                if (classGrade >= 96.5) {
                    classGrade = 4.67;
                } else if (classGrade >= 92.5) {
                    classGrade = 4.67;
                } else if (classGrade >= 89.5) {
                    classGrade = 4.37;
                } else if (classGrade >= 86.5) {
                    classGrade = 3.97;
                } else if (classGrade >= 82.5) {
                    classGrade = 3.67;
                } else if (classGrade >= 79.5) {
                    classGrade = 3.37;
                } else if (classGrade >= 76.5) {
                    classGrade = 2.97;
                } else if (classGrade >= 73.5) {
                    classGrade = 2.67;
                } else if (classGrade >= 69.5) {
                    classGrade = 2.37;
                } else if (classGrade >= 66.5) {
                    classGrade = 1.97;
                } else if (classGrade >= 62.5) {
                    classGrade = 1.67;
                } else if (classGrade >= 59.5) {
                    classGrade = 1.37;
                } else if (classGrade < 59.5) {
                    classGrade = 0.0;
                } else {
                    System.out.println("Couldn't recognize. Please run again.");
                }
            } else if (userAnswer == 2) {
                if (classGrade >= 96.5) {
                    classGrade = 4.0;
                } else if (classGrade >= 92.5) {
                    classGrade = 4.0;
                } else if (classGrade >= 89.5) {
                    classGrade = 3.7;
                } else if (classGrade >= 86.5) {
                    classGrade = 3.3;
                } else if (classGrade >= 82.5) {
                    classGrade = 3.0;
                } else if (classGrade >= 79.5) {
                    classGrade = 2.7;
                } else if (classGrade >= 76.5) {
                    classGrade = 2.3;
                } else if (classGrade >= 73.5) {
                    classGrade = 2.0;
                } else if (classGrade >= 69.5) {
                    classGrade = 1.7;
                } else if (classGrade >= 66.5) {
                    classGrade = 1.3;
                } else if (classGrade >= 62.5) {
                    classGrade = 1.0;
                } else if (classGrade >= 59.5) {
                    classGrade = 0.7;
                } else if (classGrade < 59.5) {
                    classGrade = 0.0;
                } else {
                    System.out.println("Couldn't recognize. Please run again.");
                }
            }

            System.out.println("Grade Score:" + classGrade);

            for (int j = 1; j <= numOfClasses; j++) {
                sumOfUserCredits += numOfCredits;
            }

            for (int k = 1; k <= numOfClasses; k++) {
                sumOfUserGrades += classGrade;
            }
        }

        double GPA = sumOfUserGrades / sumOfUserCredits;
        System.out.println("Name: " + userName + "\nAge: " + userAge + "\nGrade: " + userGrade + "\nGPA: " + GPA);
        if (GPA < 3.0) {
            System.out.println("Keep trying mate.");
        } else if (GPA < 4.0) {
            System.out.println("Pretty good");
        } else if (GPA >= 4.0) {
            System.out.println("EINSTEIN");
        }

/*
        //Class1 student = new Class1(userName, userAge, userGrade, class1, class2, class3, class4, class5, class6, class7, sumOfUserGrades, sumOfUserCredits);
        // System.out.println(student);
        System.out.println("Your GPA is around: ");
        Class1.printStudent();

*/
    }
}
